@extends('layout')

@section('content')
    <!-- Listings page content here -->
    <h1>LISTINGS PAGE</h1>
@endsection
