<footer>
    <p>{{ $footer }}</p>
</footer>
