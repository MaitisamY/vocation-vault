@extends('layout')

@section('content')
    <!-- Contact page content here -->
    <h1>CONTACT PAGE</h1>
@endsection