@extends('layout')

@section('content')
    <!-- About page content here -->
    <h1>ABOUT PAGE</h1>
@endsection
