@extends('layout')

@section('content')
    <!-- Categories page content here -->
    <h1>CATEGORIES PAGE</h1>
@endsection
